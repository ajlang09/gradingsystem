

<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-sm-12">
        <h1 class="float-start">CLASSES RECORD</h1>
        <a class="float-end btn btn-primary "href="<?php echo e(route('classes.add')); ?>">ADD CLASS</a>
    </div>
</div>

    <div class="row mt-2">
        <div class="col-sm-12">
        <table class="table table-striped table-hover" id="classes_records_table">
            <thead class="bg-secondary text-white">
                <tr>
                    <th>
                        Class ID
                    </th>
                    <th>
                      Class Name
                    </th> 
                    <th>
                      School year
                    </th> 
                    <th>
                        Students
                    </th>
                    <th>
                        ACTION
                    </th>
                
                </tr>
            </thead>
            
            <tbody>
                <?php $__currentLoopData = $classesRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ClassesRecords): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                     <tr>
                    <td>
                        
                        <?php echo e($ClassesRecords->class_id); ?>

                    </td>
                    
                    <td>
                       <?php echo e($ClassesRecords->class_name); ?></a>
                    </td>
                    <td>
                       <?php echo e($ClassesRecords->year); ?></a>
                    </td>
                    
                    <td>
                        <?php echo e($ClassesRecords->students()->count()); ?>

                    </td>

                    <td>
                        <a class="btn btn-warning" href="<?php echo e(route('classes.edit',$ClassesRecords->class_id)); ?>">Edit/Enroll</a>
                        <a class="btn btn-primary" href="<?php echo e(route('classes.classview',$ClassesRecords->class_id)); ?>">See Details</a>

                        <form method="post" action="<?php echo e(route('classes.delete')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($ClassesRecords->class_id); ?>">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
            </tbody>
            
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
    $('#classes_records_table').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/posts/classes.blade.php ENDPATH**/ ?>