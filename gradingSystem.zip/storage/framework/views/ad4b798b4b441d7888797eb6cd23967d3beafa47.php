<?php $__env->startSection('content'); ?>
<div class="class">
    <div class="row mt-4">
        <div class="col-6">
            <h4>Classes</h4>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped table-hover mt-2" id="class-table">
                	<thead>
                		<tr>
                			<th>Class Name</th>
                			<th>Semester</th>
                			<th>Year</th>
                			<th>Action</th>
                		</tr>
                	</thead>
                	<tbody>
                		<?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<tr>
	                		<td><?php echo e($class->class_name); ?></td>
	                		<td><?php echo e(ucfirst(str_replace('-', ' ', $class->semester))); ?></td>
	                		<td><?php echo e($class->year); ?></td>
	                		<td><a href="<?php echo e(route('student.auth.grades', $class->class_id)); ?>" class="btn btn-primary">View Grade</a></td>
                		</tr>
                		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                	</tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
<script>
$(document).ready( function () {
    $('#class-table').DataTable()
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/modules/student/index.blade.php ENDPATH**/ ?>