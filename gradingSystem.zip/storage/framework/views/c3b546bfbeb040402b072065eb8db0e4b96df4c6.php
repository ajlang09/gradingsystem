

<?php $__env->startSection('content'); ?>
<div class="subject">
    <div class="row mt-3">
        <div class="col-12">
            <div class="card mt-5">
                <form method="post" action="<?php echo e(route('users.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <h5 class="card-title">USER</h5>
                        <hr>
                        <div class="row">
                            <div class="col-sm-12 mb-1">
                                <label class="mb-1" for="name">Name</label>
                                <br>
                                <input required type="text" name="name" id="name" placeholder=""
                                class="form-control">
                            </div>
                            <div class="col-sm-12 mb-1">
                                <label class="mb-1" for="email">Email</label>
                                <br>
                                <input required type="email" name="email" id="email" placeholder=""
                                class="form-control">
                            </div>
                            <div class="col-sm-12 mb-1">
                                <label class="mb-1" for="username">Username</label>
                                <br>
                                <input required type="text" name="username" id="username" placeholder=""
                                class="form-control">
                            </div>
                            <div class="col-sm-12 mb-1">
                                <label class="mb-1" for="password">Password</label>
                                <br>
                                <input required type="password" name="password" id="password" placeholder=""
                                class="form-control">
                            </div>
                            <div class="col-sm-12 mb-1">
                                <label class="mb-1" for="password">Role</label>
                                <br>
                                <select class="form-control" name="role_id">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>" <?php echo e(strtolower($role->name) == 'teacher' ? 'selected' : ''); ?>><?php echo e(ucfirst($role->name)); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-sm-12 mb-1 mt-2">
                                <button type="submit" class="btn btn-primary float-right">Add User</button>
                                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-danger">Back</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/modules/user/create.blade.php ENDPATH**/ ?>