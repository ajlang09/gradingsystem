

<?php $__env->startSection('content'); ?>
    <div class = 'flex justify-center'>
        <div class="w-6/12 bg-white p-7 m-1 rounded-lg">
            Dashboard   
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/dashboard.blade.php ENDPATH**/ ?>