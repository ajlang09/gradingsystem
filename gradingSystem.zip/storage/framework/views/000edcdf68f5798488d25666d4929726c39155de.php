

<?php $__env->startSection('content'); ?>
<div class="components">
    <teacher-class-list />
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset(mix('/js/components.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/modules/teacher/class.blade.php ENDPATH**/ ?>