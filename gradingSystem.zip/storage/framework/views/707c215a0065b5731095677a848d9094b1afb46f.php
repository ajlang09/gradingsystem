

<?php $__env->startSection('content'); ?>
<div class="components">
    <ranking-table :classes="<?php echo e(json_encode($classes)); ?>" :subjects="<?php echo e(json_encode($subjects)); ?>"/>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset(mix('/js/components.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/modules/rank/index.blade.php ENDPATH**/ ?>