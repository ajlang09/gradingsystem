

<?php $__env->startSection('content'); ?>
<div class="subject">
    <div class="row">
        <div class="col-12 offset-3 col-sm-6">
            <div class="card mt-5">
                <div class="card-body">
                    <h5 class="card-title">SUBJECT</h5>
                    <hr>
                    <form action="<?php echo e(route('subject.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-12">
                                <label for="name">Name</label>
                                <input type="text" name="name" id="name" class="form-control mt-2" required>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-sm-12 mb-1">
                                <label class="mb-1" for="year">Year</label>
                                <br>
                                <select name="year" class="form-control">
                                    <?php for($i = 2015; $i<= date('Y');$i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e(date('Y') == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <label class="mb-1" for="teacher">Teacher</label>
                                <select class="form-control" name="user_id">
                                    <option value=""></option>
                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/modules/subject/create.blade.php ENDPATH**/ ?>