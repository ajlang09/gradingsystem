

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('student.update')); ?>" method="post">
<?php echo csrf_field(); ?>
<div class="row">
    <div class="col-md-6 offset-md-3 col-sm-12">
      <div class="card mt-5">
          <div class="card-body">
            <h5 class="card-title">STUDENT FORM</h5>
            <hr>
            <div class="row">
                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                <div class="col-sm-12 mb-1">
                    <label class="mb-1" for="email">Name</label>
                    <br>
                    <input type="text" name="name" id="name" value="<?php echo e($data->name); ?>"
                    class="form-control">
                </div>

                <div class="col-sm-12 mb-1">
                    <label class="mb-1" for="password">Year and Section</label>
                    <input type="yearandsection" name="yearandsection" id="yearandsection" value="<?php echo e($data->yearandsection); ?>"
                    class="form-control">
                </div>

                  <div class="col-sm-12 mb-1">
                      <label class="mb-1" for="email">Student ID</label>
                      <br>
                      <input type="stud_id" name="stud_id" id="stud_id" value="<?php echo e($data->stud_id); ?>"
                      class="form-control">
                  </div>

                  <div class="col-sm-12 mb-1">
                      <label class="mb-1" for="password">Email</label>
                      <input type="email" name="email" id="email" value="<?php echo e($data->email); ?>"
                      class="form-control">
                  </div>

                 <div class="col-sm-12 mb-1">
                    <label class="mb-1" for="password">Contact No.</label>
                    <input type="contact_no" name="contact_no" id="contact_no" value="<?php echo e($data->contact_no); ?>"
                    class="form-control">
                 </div>

                  <div class="col-sm-12 mb-1 mt-2">
                      <button type="submit" class="btn btn-primary">UPDATE</button>
                  </div>
            </div>
          </div>
      </div>
  </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/posts/student_edit.blade.php ENDPATH**/ ?>