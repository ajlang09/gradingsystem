

<?php $__env->startSection('content'); ?>
<div class="row mt-4 mb-4">
    <div class="col-12">
        <h1><?php echo e($class->class_name); ?></h1>        
    </div>
</div>
<div class="row">
    <div class="col-12 col-sm-6 pl-2 pr-2">
        <div class="row mt-3">
            <div class="col-sm-12">
                <h3 class="float-start">Students</h3>
                
            </div>
        </div>
        <div class="row mt-2">
            <div class="col-sm-12">
                <table class="table table-striped table-hover" id="classes_records_table">
                    <thead class="bg-secondary text-white">
                        <tr>
                            <th>
                                Student Name
                            </th>
                            <th>
                                Student ID
                            </th>
                            <th>
                                ACTION
                            </th>
                            
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($student->name); ?>

                            </td>
                            
                            <td>
                                <?php echo e($student->stud_id); ?>

                            </td>
                            <td>
                                <a class="btn btn-warning" href="<?php echo e(route('student.grades',[$class->class_id, $student->id])); ?>">Grades</a>
                                <form method="post" action="<?php echo e(route('remove.student')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="class_id" value="<?php echo e($class->class_id); ?>">
                                    <input type="hidden" name="student_id" value="<?php echo e($student->id); ?>">
                                    <button type="submit" class="btn btn-danger">UNENROLL</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                    
                </table>
            </div>
        </div>
    </div>
    <div class="col-12 col-sm-6">
        <div class="row mt-3">
            <div class="col-sm-12">
                <h3 class="float-start">Subjects</h3>
                
            </div>
        </div>
        <div class="row mt-2">
            <div class="col-sm-12">
                <table class="table table-striped table-hover" id="classes_subject">
                    <thead class="bg-secondary text-white">
                        <tr>
                            <th>
                                Name
                            </th>
                            <th>
                                ACTION
                            </th>
                            
                        </tr>
                    </thead>
                    
                    <tbody>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($subject->name); ?>

                            </td>
                            
                            <td>
                                <form method="post" action="<?php echo e(route('remove.subject')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="class_id" value="<?php echo e($class->class_id); ?>">
                                    <input type="hidden" name="subject_id" value="<?php echo e($subject->id); ?>">
                                    <button type="submit" class="btn btn-danger">Remove subject</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
                    
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$(document).ready( function () {
    $('#classes_records_table').DataTable();
    $('#classes_subject').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/posts/classview.blade.php ENDPATH**/ ?>