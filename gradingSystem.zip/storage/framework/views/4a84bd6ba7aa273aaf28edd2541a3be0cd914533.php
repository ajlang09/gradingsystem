<script>
<?php $__currentLoopData = session('flash_notification', collect())->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    setTimeout(function(){
        <?php if($message['level'] == 'error'): ?>
            alertify.error("<?php echo e($message['message']); ?>")
        <?php elseif($message['level'] == 'danger'): ?>
            alertify.error("<?php echo e($message['message']); ?>")
        <?php else: ?>
            alertify.success("<?php echo e($message['message']); ?>")
        <?php endif; ?>
    },300)
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>

<?php echo session()->forget('flash_notification'); ?>

<?php /**PATH C:\Users\User\gradingSystem\resources\views/vendor/flash/message.blade.php ENDPATH**/ ?>