

<?php $__env->startSection('content'); ?>
<div class="subject">
    <div class="row mt-4">
        <div class="col-6">
            <h4><?php echo e($subject->name); ?></h4>
        </div>
    </div>
    <div class="row mt-3">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped table-hover mt-2" id="subject-table">
                    <thead class="bg-secondary text-white">
                        <tr>
                            <th>Student</th>
                            <th>Class</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $student['students']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rawStudent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($rawStudent->name); ?></td>
                                    <td><?php echo e($student['class']->class_name); ?> <?php echo e($student['class']->year ?'- '.$student['class']->year:''); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('students.subject',[$rawStudent->id, $student['class']->class_id])); ?>" class="btn btn-warning">Grade</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
$(document).ready( function () {
    $('#subject-table').DataTable({
         "aaSorting": [],
    })
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/modules/teacher/subject_student.blade.php ENDPATH**/ ?>