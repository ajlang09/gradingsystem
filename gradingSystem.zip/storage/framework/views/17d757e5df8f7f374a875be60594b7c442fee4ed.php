

<?php $__env->startSection('content'); ?>
<div class="row mt-3">
    <div class="col-sm-12">
        <h1 class="float-start">STUDENT RECORD</h1>
        <a class="float-end btn btn-primary "href="<?php echo e(route('student.add')); ?>">ADD STUDENT RECORD</a>
    </div>
</div>

    <div class="row mt-2">
        <div class="col-sm-12">
        <table class="table table-striped table-hover" id="student_record_table">
            <thead class="bg-secondary text-white">
                <tr>
                    <th>
                        Student
                    </th>
                    <th>
                        Section 
                    </th>
                    <th>
                        Contact No
                    </th>
                    <th>
                        Email
                    </th>
                    <th>
                        Student ID
                    </th>   
                    <th>
                        ACTION
                    </th>     
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $studentRecords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentRecord): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                     <tr>
                    <td>
                        <?php echo e($studentRecord->name); ?>

                    </td>
                    
                    <td>
                        <?php echo e($studentRecord->yearandsection); ?>

                    </td>
                    
                    <td>
                        <?php echo e($studentRecord->contact_no); ?>

                    </td>

                    <td>
                        <?php echo e($studentRecord->email); ?>

                    </td>
                    <td>
                        <?php echo e($studentRecord->stud_id); ?>

                    </td>
                    <td>
                        <a class="btn btn-warning" href="<?php echo e(route('student.edit',$studentRecord->id)); ?>">Edit</a>
                        <form method="post" action="<?php echo e(route('student.delete')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($studentRecord->id); ?>">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
            </tbody>
            
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready( function () {
    $('#student_record_table').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\gradingSystem\resources\views/posts/student.blade.php ENDPATH**/ ?>