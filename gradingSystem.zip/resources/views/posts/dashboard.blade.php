@extends('layouts.app')

@section('content')
    <div class = 'flex justify-center'>
        
        <div class="w-6/12 bg-white p-7 m-1 rounded-lg">
            Dashboard   
        </div>
    </div>
@endsection